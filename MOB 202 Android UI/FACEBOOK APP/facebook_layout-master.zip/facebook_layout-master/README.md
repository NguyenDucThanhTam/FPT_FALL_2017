# facebook_layout design Android
![alt tag](https://raw.githubusercontent.com/phamvansy/facebook_layout/master/Screenshot_2.png)
