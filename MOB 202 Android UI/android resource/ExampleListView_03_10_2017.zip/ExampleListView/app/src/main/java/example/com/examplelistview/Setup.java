package example.com.examplelistview;

/**
 * Created by giang on 10/3/17.
 */

public class Setup {

    public static final String MYDATA_BUNDLE_NAME = "MYDATA_BUNDLE_NAME";
}
