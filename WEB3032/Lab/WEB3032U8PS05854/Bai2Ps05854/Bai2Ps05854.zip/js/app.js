Ext.require(‘Ext.container.Viewport’);
Ext.applitcation({
	name: 'Fpoly',
	
	launch: function(){
		Ext.create("Ext.tab.panel",{
			fullscreen:true,
			items:[
				{
					title:'Home',
					iconCls: 'home'
					html:'Welcome'
				}
			]
		});
	}
});