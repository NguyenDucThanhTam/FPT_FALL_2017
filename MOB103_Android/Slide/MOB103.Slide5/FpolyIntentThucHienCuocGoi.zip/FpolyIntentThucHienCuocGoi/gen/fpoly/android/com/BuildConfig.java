/** Automatically generated file. DO NOT MODIFY */
package fpoly.android.com;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}