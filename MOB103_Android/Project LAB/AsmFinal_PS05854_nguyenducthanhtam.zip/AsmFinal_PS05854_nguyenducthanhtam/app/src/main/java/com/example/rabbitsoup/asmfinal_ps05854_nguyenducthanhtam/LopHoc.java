package com.example.rabbitsoup.asmfinal_ps05854_nguyenducthanhtam;

/**
 * Created by R.S on 21/8/2017.
 */

public class LopHoc {
    private String tenLop;
    private String maLop;


    public String getTenLop() {
        return tenLop;
    }

    public void setTenLop(String tenLop) {
        this.tenLop = tenLop;
    }

    public String getMaLop() {
        return maLop;
    }

    public void setMaLop(String maLop) {
        this.maLop = maLop;
    }
}
