package com.example.rabbitsoup.asmfinal_ps05854_nguyenducthanhtam;

/**
 * Created by R.S on 21/8/2017.
 */

public class SinhVien {
    private int id;
    private String name,ngaySinh,maLop;
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getMaLop() {
        return maLop;
    }

    public void setMaLop(String maLop) {
        this.maLop = maLop;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getNgaySinh() {
        return ngaySinh;
    }

    public void setNgaySinh(String ngaySinh) {
        this.ngaySinh = ngaySinh;
    }

}
