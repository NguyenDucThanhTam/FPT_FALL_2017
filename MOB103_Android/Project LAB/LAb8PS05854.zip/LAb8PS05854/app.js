﻿Ext.application({
	name: 'Sencha',
	launch: function() {
		Ext.create("Ext.tab.Panel", {
			fullscreen: true,
			tabBarPosition: 'bottom',
			items: [
				{
					iconCls: 'action',
					title: 'Home',
					style: 'background-color:white;',
					html: [
						
						'<img src="images/dmx.jpg"/>',
						'<h1Bàn làm việc hiệu quả</h1>',
						"<p></p>",
						'<h2></h2>'
				
					].join("")
				}, {
					xtype: 'nestedlist',
					iconCls: 'star',
					title: 'Blog',
					style: 'background-color:white;',
					displayField: 'title',
					store: {
						type : 'tree',
						fields: [
							'title', 'link', 'author', 'contentSnippet', 'content' ,
							{name: 'leaf', defaultValue: true}
						],
						root: {
							leaf: false
						},
						proxy: {
							type: 'jsonp',
							url: 'https://ajax.googleapis.com/ajax/services/feed/load?v=1.0&q=http://www.24h.com.vn/upload/rss/thethao.rss',
							reader: {
								type: 'json',
								rootProperty: 'responseData.feed.entries'
							}
						}
					},
					detailCard: {
						xtype: 'panel',
						scrollable: true,
						styleHtmlContent: true
					},
					listener: {
						itemtap: function(nestedlist, list, index, element, post) {
							this.getDetailCard().setHtml(post.get('content'));
						}
					}
				}, {
					title: 'Contact',
					iconCls: 'user',
					xtype: 'formpanel',
					url: 'contact.php',
					layout: 'vbox',
					items: [
						{
							xtype: 'fieldset', 
							
							title: 'Contact Fpoly',
							instructions: '(email address is optional)',
							items: [
								{
									xtype: 'textfield',
									label: 'Họ và tên ',								
								},
								{
									xtype: 'emailfield',
									label: 'Email:',
									placeholder: 'Hello'
								},
								{
									xtype: 'textareafield',
									label: 'Nội dung:'
								}
							]
						},
						{
							xtype: 'button',
							text: 'Send',
							ui: 'confirm',
							handler: function() {
								this.up('formpanel').submit();
							}
						}
					]
				}
			]
		});
	}
});